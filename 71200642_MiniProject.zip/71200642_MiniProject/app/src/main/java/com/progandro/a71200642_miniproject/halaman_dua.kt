package com.progandro.a71200642_miniproject

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import androidx.appcompat.app.AppCompatActivity

class halaman_dua : AppCompatActivity() {
    var total2 = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.halaman_dua)
        val total1 = intent.getIntExtra("kirim", 0)
        val btNext = findViewById<Button>(R.id.btnNext2)

        btNext.setOnClickListener {
            val intent = Intent(this,halaman_tiga::class.java)
            var hasil = total1 + total2
            intent.putExtra("kirim",hasil)
            startActivity(intent)
        }
    }
        fun onRadioButtonClicked2(view: View) {
            if (view is RadioButton) {
                // Is the button now checked?
                val checked = view.isChecked

                // Check which radio button was clicked
                when (view.getId()) {
                    R.id.rbJam10 ->
                        if (checked) {
                            total2 += 100000
                        }
                    R.id.rbJam16 ->
                        if (checked) {
                            total2 += 150000
                        }
                    R.id.rbJam20 ->
                        if (checked) {
                            total2 += 200000
                        }
                    R.id.rbEkonomi ->
                        if (checked) {
                            total2 += 50000
                        }
                    R.id.rbBisnis ->
                        if (checked) {
                            total2 += 75000
                        }
                    R.id.rbTujuanBali ->
                        if (checked) {
                            total2 += 150000
                        }
                }
            }
        }
    }
