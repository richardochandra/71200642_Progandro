package com.progandro.a71200642_miniproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup

class MainActivity : AppCompatActivity() {
    var total = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btNext = findViewById<Button>(R.id.btnNext1)
        val rgKotaAsal = findViewById<RadioGroup>(R.id.rgKotaAsal)
        val rgKotaTujuan = findViewById<RadioGroup>(R.id.rgKotaTujuan)
        btNext.setOnClickListener {
            val intent = Intent(this, halaman_dua::class.java)
            intent.putExtra("kirim", total)
            startActivity(intent)
        }
    }

    fun onRadioButtonClicked(view: View) {
        if (view is RadioButton) {
            // Is the button now checked?
            val checked = view.isChecked

            // Check which radio button was clicked
            when (view.getId()) {
                R.id.rbAsalYogya ->
                    if (checked) {
                        total += 100000
                    }
                R.id.rbAsalJkt ->
                    if (checked) {
                        total += 150000
                    }
                R.id.rbAsalBali ->
                    if (checked) {
                        total += 200000
                    }
                R.id.rbTujuanYogya ->
                    if (checked) {
                        total += 50000
                    }
                R.id.rbTujuanJkt ->
                    if (checked) {
                        total += 75000
                    }
                R.id.rbTujuanBali ->
                    if (checked) {
                        total += 150000
                    }
            }
        }
    }
}