package com.progandro.a71200642_miniproject

import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class halaman_tiga : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.halaman_tiga)
        val hasil = intent.getStringExtra("hasil").toString()
        val edtTotal = findViewById<EditText>(R.id.edtTOTAL)
        edtTotal.setText("total Harga " + hasil)
    }
}